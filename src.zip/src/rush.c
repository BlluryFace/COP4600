#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>

#define MAX_INPUT 256       // Maximum input length
#define MAX_ARGS 64         // Maximum number of arguments
#define MAX_PATHS 10        // Maximum number of directories in PATH
#define MAX_PATH_LEN 128    // Maximum length of each path

// Global path list and count
char **pathlist = NULL;
int pathcount = 0;

// ------------------- Error Handling -------------------
void error() {
    // Write error message directly to stderr (unbuffered)
    write(STDERR_FILENO, "An error has occurred\n", 22);
}

// ------------------- Execute External Command -------------------
void execute_exe(char **args, int arg_count, char program[]) {
    int fd = -1; // file descriptor for output redirection

    // Check for output redirection ">"
    for (int i = 0; i < arg_count; i++) {
        if (strcmp(args[i], ">") == 0) {
            // Must have exactly one filename after ">"
            if (i != arg_count - 2) {
                error();
                return;
            }
            fd = open(args[i + 1], O_CREAT | O_WRONLY | O_TRUNC, 0644);
            if (fd < 0) {
                error();
                return;
            }
            args[i] = NULL; // truncate args at ">"
            break;
        }
    }

    // Fork a child process
    pid_t pid = fork();
    if (pid < 0) {
        error(); // fork failed
        return;
    } else if (pid == 0) {
        // Child process
        if (fd != -1) {
            if (dup2(fd, STDOUT_FILENO) < 0) { // redirect stdout
                error();
                _exit(1);
            }
            close(fd);
        }
        args[0] = program; // set argv[0] to full executable path
        execv(program, args); // execute command

        // execv failed
        error();
        _exit(1);
    } else {
        // Parent process waits for child
        waitpid(pid, NULL, 0);
        if (fd != -1) close(fd);
    }
}

// ------------------- Main Shell Loop -------------------
int main(int argc, char *argv[]) {
    if (argc != 1) { // Shell does not accept command-line args
        error();
        exit(1);
    }

    // Initialize default PATH to /bin
    pathlist = malloc(sizeof(char*));
    if (!pathlist) {
        perror("malloc failed");
        exit(1);
    }
    pathlist[0] = strdup("/bin");
    pathcount = 1;

    char *line = NULL;
    size_t len = 0;

    while (1) {
        // Print prompt
        printf("rush> ");
        fflush(stdout);

        // Read input
        if (getline(&line, &len, stdin) == -1) {
            break; // EOF
        }

        // Tokenize input into args[]
        char *args[MAX_ARGS];
        int arg_count = 0;
        char *tok = strtok(line, " \t\n");

        while (tok != NULL && arg_count < MAX_ARGS - 1) {
            if (strcmp(tok, ">") == 0) {
                // Handle redirection later in execute_exe
                args[arg_count++] = tok;
                tok = strtok(NULL, " \t\n");
                if (tok != NULL) args[arg_count++] = tok;
                break;
            } else {
                args[arg_count++] = tok;
            }
            tok = strtok(NULL, " \t\n");
        }
        args[arg_count] = NULL; // null-terminate args

        if (arg_count == 0) continue; // empty input

        // ------------------- Built-in Commands -------------------
        // exit
        if (strcmp(args[0], "exit") == 0) {
            if (args[1] != NULL) {
                error(); // exit takes no arguments
                continue;
            }
            exit(0);
        }

            // cd
        else if (strcmp(args[0], "cd") == 0) {
            if (arg_count != 2 || chdir(args[1]) != 0) {
                error();
            }
            continue;
        }

            // path
        else if (strcmp(args[0], "path") == 0) {
            // Free old path list
            for (int i = 0; i < pathcount; i++) free(pathlist[i]);
            free(pathlist);

            // Count new paths
            int count = 0;
            for (int i = 1; args[i] != NULL; i++) count++;

            // Allocate new path list
            if (count > 0) {
                pathlist = malloc(sizeof(char*) * count);
                if (!pathlist) { perror("malloc"); exit(1); }
                pathcount = count;

                for (int i = 0; i < count; i++) {
                    pathlist[i] = strdup(args[i + 1]);
                }
            } else {
                pathlist = NULL;
                pathcount = 0;
            }
            continue;
        }

        // ------------------- External Command -------------------
        char program[MAX_PATH_LEN + 128]; // buffer for full path
        int found = 0;

        char full[256];
        for (int i = 0; i < pathcount; i++) {
            snprintf(full, sizeof(full), "%s/%s", pathlist[i], args[0]);
            if (access(full, X_OK) == 0) {
                strncpy(program, full, sizeof(program) - 1);
                program[sizeof(program) - 1] = '\0';
                found = 1;
                break; // stop at first valid executable
            }
        }

        if (!found) {
            error();
            continue;
        }

        // Execute external command (with optional redirection)
        execute_exe(args, arg_count, program);
    }

    // Cleanup
    for (int i = 0; i < pathcount; i++) free(pathlist[i]);
    free(pathlist);
    free(line);

    return 0;
}